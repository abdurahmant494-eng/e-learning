<?php
require_once __DIR__ . '/../auth.php';
require_admin();
require_once __DIR__ . '/../db.php';

$message = '';
if (isset($_GET['action'], $_GET['id'])) {
    $action = $_GET['action'];
    $userId = intval($_GET['id']);
    if ($userId > 0) {
        if ($action === 'promote' && isset($_GET['role']) && in_array($_GET['role'], ['instructor', 'admin'], true)) {
            $newRole = $_GET['role'];
            $isAdmin = $newRole === 'admin' ? 1 : 0;
            $stmt = $mysqli->prepare('UPDATE users SET role = ?, is_admin = ? WHERE id = ?');
            $stmt->bind_param('sii', $newRole, $isAdmin, $userId);
            if ($stmt->execute()) {
                $message = 'User updated successfully.';
            }
            $stmt->close();
        }
        if ($action === 'demote') {
            $newRole = 'student';
            $isAdmin = 0;
            $stmt = $mysqli->prepare('UPDATE users SET role = ?, is_admin = ? WHERE id = ?');
            $stmt->bind_param('sii', $newRole, $isAdmin, $userId);
            if ($stmt->execute()) {
                $message = 'User demoted to student.';
            }
            $stmt->close();
        }
    }
}

$users = [];
$result = $mysqli->query("SELECT id, name, email, role, is_admin, created_at FROM users ORDER BY created_at DESC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    $result->free();
}

$title = 'Manage Users';
$page = 'admin';
include __DIR__ . '/../includes/header.php';
?>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h1 class="mb-0">Manage Users</h1>
                            <p class="mb-2">Admin tools for controlling students, instructors, and system accounts.</p>
                        </div>
                        <a href="invite_user.php" class="btn btn-primary">Invite / Create User</a>
                    </div>
                    <?php if ($message): ?>
                        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Joined</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?= $user['id'] ?></td>
                                <td><?= htmlspecialchars($user['name']) ?></td>
                                <td><?= htmlspecialchars($user['email']) ?></td>
                                <td><?= htmlspecialchars($user['role']) ?><?= $user['is_admin'] ? ' (admin)' : '' ?></td>
                                <td><?= $user['created_at'] ?></td>
                                <td>
                                    <?php if ($user['role'] !== 'admin'): ?>
                                        <a href="?action=promote&role=admin&id=<?= $user['id'] ?>" class="btn btn-sm btn-success mb-1">Make Admin</a>
                                    <?php endif; ?>
                                    <?php if ($user['role'] !== 'instructor'): ?>
                                        <a href="?action=promote&role=instructor&id=<?= $user['id'] ?>" class="btn btn-sm btn-warning mb-1">Make Instructor</a>
                                    <?php endif; ?>
                                    <?php if ($user['role'] !== 'student'): ?>
                                        <a href="?action=demote&id=<?= $user['id'] ?>" class="btn btn-sm btn-secondary">Make Student</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php include __DIR__ . '/../includes/footer.php';
