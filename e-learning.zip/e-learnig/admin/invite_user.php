<?php
require_once __DIR__ . '/../auth.php';
require_admin();
require_once __DIR__ . '/../db.php';

$errors = [];
$success = '';
$name = '';
$email = '';
$role = 'student';
$sendInvite = false;
$invitePreview = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';
    $role = $_POST['role'] ?? 'student';
    $sendInvite = isset($_POST['send_invite']);

    if ($name === '') {
        $errors[] = 'Please enter a full name.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters long.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }
    if (!in_array($role, ['student', 'instructor', 'admin'], true)) {
        $errors[] = 'Please select a valid role.';
    }

    if (empty($errors)) {
        $stmt = $mysqli->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $errors[] = 'This email is already registered. Use manage users to update the user role.';
        }
        $stmt->close();
    }

    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $isAdmin = $role === 'admin' ? 1 : 0;
        $stmt = $mysqli->prepare('INSERT INTO users (name, email, password, role, is_admin) VALUES (?, ?, ?, ?, ?)');
        $stmt->bind_param('ssssi', $name, $email, $hash, $role, $isAdmin);
        if ($stmt->execute()) {
            $success = 'User created successfully with role: ' . htmlspecialchars($role) . '.';
            if ($sendInvite) {
                $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
                $basePath = rtrim(dirname(dirname($_SERVER['REQUEST_URI'])), '/\\');
                $inviteLink = $scheme . '://' . $_SERVER['HTTP_HOST'] . $basePath . '/login.php';
                $invitePreview = "Hello " . htmlspecialchars($name) . ",\n\nYour account has been created for Borana University e-learning.\n\nLogin URL: " . $inviteLink . "\nEmail: " . htmlspecialchars($email) . "\nPassword: " . htmlspecialchars($password) . "\nRole: " . htmlspecialchars($role) . "\n\nPlease log in and change your password after first access.\n";
            }
            $name = '';
            $email = '';
            $role = 'student';
        } else {
            $errors[] = 'Unable to create user: ' . $mysqli->error;
        }
        $stmt->close();
    }
}

$title = 'Invite / Create User';
$page = 'admin';
include __DIR__ . '/../includes/header.php';
?>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h1 class="mb-4">Invite / Create User</h1>
                    <p class="mb-4">Create a new student, instructor, or admin account from the admin panel.</p>
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php foreach ($errors as $error): ?>
                                    <li><?= htmlspecialchars($error) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php if ($success): ?>
                        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
                    <?php endif; ?>
                    <?php if ($invitePreview): ?>
                        <div class="alert alert-secondary">
                            <h5 class="mb-3">Invitation Email Preview</h5>
                            <pre class="mb-0" style="white-space: pre-wrap; word-break: break-word;"><?= htmlspecialchars($invitePreview) ?></pre>
                        </div>
                    <?php endif; ?>
                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($name) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email address</label>
                            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($email) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirm Password</label>
                            <input type="password" name="confirm" class="form-control" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Role</label>
                            <select name="role" class="form-select" required>
                                <option value="student" <?= $role === 'student' ? 'selected' : '' ?>>Student</option>
                                <option value="instructor" <?= $role === 'instructor' ? 'selected' : '' ?>>Instructor</option>
                                <option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>Admin</option>
                            </select>
                        </div>
                        <div class="form-check mb-4">
                            <input class="form-check-input" type="checkbox" value="1" id="send_invite" name="send_invite" <?= $sendInvite ? 'checked' : '' ?>>
                            <label class="form-check-label" for="send_invite">Show invitation email preview</label>
                        </div>
                        <button type="submit" class="btn btn-primary">Create User</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php include __DIR__ . '/../includes/footer.php';
