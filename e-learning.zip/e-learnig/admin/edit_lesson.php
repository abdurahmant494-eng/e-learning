<?php
require_once __DIR__ . '/../auth.php';
require_login();
$user = current_user();
if (empty($user['is_admin'])) {
    header('Location: ../index.php');
    exit;
}

require_once __DIR__ . '/../db.php';

$id = intval($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: lessons.php');
    exit;
}

$stmt = $mysqli->prepare("SELECT * FROM lessons WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$lesson = $res->fetch_assoc();
$stmt->close();
if (!$lesson) {
    header('Location: lessons.php');
    exit;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete'])) {
        // delete lesson and associated file
        if (!empty($lesson['material_file'])) {
            $path = __DIR__ . '/../' . MATERIALS_PATH . '/' . $lesson['material_file'];
            if (is_file($path)) @unlink($path);
        }
        $del = $mysqli->prepare("DELETE FROM lessons WHERE id = ?");
        $del->bind_param('i', $id);
        $del->execute();
        $del->close();
        header('Location: lessons.php');
        exit;
    }

    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $video_url = trim($_POST['video_url'] ?? '');
    $uploadedFilename = $lesson['material_file'];

    if (!empty($_FILES['material']['name']) && $_FILES['material']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['material'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['pdf','doc','docx','ppt','pptx','zip','mp4','mov','png','jpg','jpeg'];
        if (!in_array($ext, $allowed)) {
            $message = 'File type not allowed.';
        } elseif ($file['size'] > 50 * 1024 * 1024) {
            $message = 'File too large (max 50MB).';
        } else {
            $filename = 'material_' . $id . '_' . time() . '.' . $ext;
            $destDir = __DIR__ . '/../' . MATERIALS_PATH;
            if (!is_dir($destDir)) mkdir($destDir, 0755, true);
            $dest = $destDir . '/' . $filename;
            if (move_uploaded_file($file['tmp_name'], $dest)) {
                // remove old
                if (!empty($lesson['material_file'])) {
                    $old = $destDir . '/' . $lesson['material_file'];
                    if (is_file($old)) @unlink($old);
                }
                $uploadedFilename = $filename;
            } else {
                $message = 'Failed to move uploaded file.';
            }
        }
    }

    if (empty($message)) {
        $upd = $mysqli->prepare("UPDATE lessons SET title = ?, content = ?, video_url = ?, material_file = ? WHERE id = ?");
        $upd->bind_param('ssssi', $title, $content, $video_url, $uploadedFilename, $id);
        if ($upd->execute()) {
            $message = 'Lesson updated.';
            // refresh lesson
            $lesson['title'] = $title;
            $lesson['content'] = $content;
            $lesson['video_url'] = $video_url;
            $lesson['material_file'] = $uploadedFilename;
        } else {
            $message = 'DB error: ' . $mysqli->error;
        }
        $upd->close();
    }
}

$titlePage = 'Edit Lesson';
include __DIR__ . '/../includes/header.php';
?>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h1 class="mb-4">Edit Lesson #<?= $lesson['id'] ?></h1>
                    <?php if ($message): ?>
                        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
                    <?php endif; ?>
                    <form method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">Title</label>
                            <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($lesson['title']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Content</label>
                            <textarea name="content" class="form-control" rows="6"><?= htmlspecialchars($lesson['content']) ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Video URL</label>
                            <input type="text" name="video_url" class="form-control" value="<?= htmlspecialchars($lesson['video_url']) ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Current Material</label>
                            <div>
                                <?php if (!empty($lesson['material_file'])): ?>
                                    <a href="<?= '../' . MATERIALS_PATH . '/' . $lesson['material_file'] ?>" target="_blank">Download</a>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Replace Material (optional)</label>
                            <input type="file" name="material" class="form-control">
                        </div>
                        <div class="d-flex gap-2">
                            <button class="btn btn-primary">Save Changes</button>
                            <button class="btn btn-danger" type="submit" name="delete" onclick="return confirm('Delete this lesson?')">Delete Lesson</button>
                            <a href="lessons.php" class="btn btn-secondary">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php include __DIR__ . '/../includes/footer.php';
