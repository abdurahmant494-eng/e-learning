<?php
require_once __DIR__ . '/../auth.php';
require_admin();
require_once __DIR__ . '/../db.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titleText = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = trim($_POST['price'] ?? '');
    $teacher = trim($_POST['teacher'] ?? '');
    $duration = trim($_POST['duration'] ?? '');
    $students = trim($_POST['students'] ?? '0 Students');

    if ($titleText === '' || $description === '' || $price === '' || $teacher === '') {
        $message = 'Please complete all required course fields.';
    } else {
        $stmt = $mysqli->prepare('INSERT INTO courses (title, description, price, teacher, duration, students, image) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $defaultImage = 'course-1.jpg';
        $stmt->bind_param('sssssss', $titleText, $description, $price, $teacher, $duration, $students, $defaultImage);
        if ($stmt->execute()) {
            $message = 'Course added successfully.';
        } else {
            $message = 'Unable to add course: ' . $mysqli->error;
        }
        $stmt->close();
    }
}

$courses = [];
$result = $mysqli->query("SELECT * FROM courses ORDER BY id DESC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $courses[] = $row;
    }
    $result->free();
}

$title = 'Manage Courses';
$page = 'admin';
include __DIR__ . '/../includes/header.php';
?>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-lg-8">
                    <h1 class="mb-3">Manage Courses</h1>
                    <p class="mb-4">Create, update, or remove courses from the Borana University catalog.</p>
                    <?php if ($message): ?>
                        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
                    <?php endif; ?>
                    <form method="post">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Course Title</label>
                                <input type="text" name="title" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Teacher</label>
                                <input type="text" name="teacher" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Price</label>
                                <input type="text" name="price" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Duration</label>
                                <input type="text" name="duration" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Students</label>
                                <input type="text" name="students" class="form-control" value="0 Students">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Description</label>
                                <textarea name="description" class="form-control" rows="4" required></textarea>
                            </div>
                            <div class="col-12">
                                <button class="btn btn-primary">Add New Course</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Teacher</th>
                                    <th>Price</th>
                                    <th>Duration</th>
                                    <th>Students</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($courses as $course): ?>
                                    <tr>
                                        <td><?= $course['id'] ?></td>
                                        <td><?= htmlspecialchars($course['title']) ?></td>
                                        <td><?= htmlspecialchars($course['teacher']) ?></td>
                                        <td><?= htmlspecialchars($course['price']) ?></td>
                                        <td><?= htmlspecialchars($course['duration']) ?></td>
                                        <td><?= htmlspecialchars($course['students']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include __DIR__ . '/../includes/footer.php';
