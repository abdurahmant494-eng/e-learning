<?php
$page = 'about';
$title = 'About';
include 'includes/header.php';
?>

    <!-- Page Header Start -->
    <div class="container-fluid page-header py-5 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <h1 class="display-1 text-white mb-3">About Us</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb text-uppercase">
                    <li class="breadcrumb-item"><a class="text-white" href="index.php">Home</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">About</li>
                </ol>
            </nav>
        </div>
    </div>
    <!-- Page Header End -->

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <img class="img-fluid position-absolute w-100 h-100" src="<?= IMG_PATH ?>/about.jpg" alt="" style="object-fit: cover;">
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <h6 class="section-title bg-white text-start text-primary pe-3">About Us</h6>
                    <h1 class="mb-4">Welcome to Borana University eLEARNING</h1>
                    <p class="mb-4">We offer modern online learning with courses taught by experienced instructors, flexible schedules, and hands-on projects.</p>
                    <p class="mb-4">Our mission is to help every learner grow skills, build confidence, and achieve real career outcomes through accessible education.</p>
                    <div class="row gy-2 gx-4 mb-4">
                        <div class="col-sm-6"><p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Skilled Instructors</p></div>
                        <div class="col-sm-6"><p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Online Classes</p></div>
                        <div class="col-sm-6"><p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>International Certificate</p></div>
                        <div class="col-sm-6"><p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Flexible Learning</p></div>
                    </div>
                    <a class="btn btn-primary py-3 px-5 mt-2" href="contact.php">Contact Us</a>
                </div>
            </div>
        </div>
    </div>

<?php include 'includes/footer.php'; ?>
