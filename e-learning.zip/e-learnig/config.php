<?php
// XAMPP MySQL defaults: root / no password
define('DB_HOST', 'localhost');
define('DB_NAME', 'elearning');
define('DB_USER', 'root');
define('DB_PASS', '');

define('CSS_PATH', 'css');
define('IMG_PATH', 'img');
define('JS_PATH', 'js');
define('LIB_PATH', 'lib');
define('UPLOADS_PATH', 'uploads');
define('AVATAR_PATH', UPLOADS_PATH . '/avatars');
define('MATERIALS_PATH', UPLOADS_PATH . '/materials');

if (php_sapi_name() !== 'cli' && isset($_SERVER['DOCUMENT_ROOT'])) {
    $documentRoot = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT']));
    $siteRoot = str_replace('\\', '/', realpath(__DIR__));
    $basePath = str_replace($documentRoot, '', $siteRoot);
    $basePath = '/' . trim($basePath, '/');
    if ($basePath === '/') {
        $basePath = '';
    }
    define('BASE_URL', $basePath);
} else {
    define('BASE_URL', '');
}
