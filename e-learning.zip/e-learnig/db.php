<?php
require_once __DIR__ . '/config.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($mysqli->connect_errno) {
    $db_error = $mysqli->connect_error;
    $mysqli = null;
} else {
    $mysqli->set_charset('utf8mb4');

    // Users table (ensure admin flag and avatar column exist)
    $mysqli->query("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role ENUM('student', 'instructor', 'admin') DEFAULT 'student',
        is_admin TINYINT(1) DEFAULT 0,
        avatar VARCHAR(255) DEFAULT NULL,
        department_id INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Ensure legacy installs get the new columns
    $mysqli->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS role ENUM('student', 'instructor', 'admin') DEFAULT 'student'");
    $mysqli->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS department_id INT DEFAULT NULL");
    $mysqli->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS is_admin TINYINT(1) DEFAULT 0");
    $mysqli->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar VARCHAR(255) DEFAULT NULL");

    // Departments table
    $mysqli->query("CREATE TABLE IF NOT EXISTS departments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL UNIQUE,
        description TEXT,
        head_id INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (head_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Lessons: each course can have multiple lessons
    $mysqli->query("CREATE TABLE IF NOT EXISTS lessons (
        id INT AUTO_INCREMENT PRIMARY KEY,
        course_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        content TEXT,
        video_url VARCHAR(255) DEFAULT NULL,
        material_file VARCHAR(255) DEFAULT NULL,
        sort_order INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Progress tracking for users per lesson
    $mysqli->query("CREATE TABLE IF NOT EXISTS progress (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        lesson_id INT NOT NULL,
        completed TINYINT(1) DEFAULT 0,
        completed_at TIMESTAMP NULL DEFAULT NULL,
        UNIQUE KEY(user_id, lesson_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Comments / discussion per course
    $mysqli->query("CREATE TABLE IF NOT EXISTS comments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        course_id INT NOT NULL,
        content TEXT NOT NULL,
        parent_id INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
        FOREIGN KEY (parent_id) REFERENCES comments(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Generated certificates
    $mysqli->query("CREATE TABLE IF NOT EXISTS certificates (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        course_id INT NOT NULL,
        cert_file VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Exercises/Quizzes table
    $mysqli->query("CREATE TABLE IF NOT EXISTS exercises (
        id INT AUTO_INCREMENT PRIMARY KEY,
        course_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        questions JSON NOT NULL,
        passing_score INT DEFAULT 60,
        attempts_allowed INT DEFAULT 3,
        instructor_id INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
        FOREIGN KEY (instructor_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Exercise submissions
    $mysqli->query("CREATE TABLE IF NOT EXISTS exercise_submissions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        exercise_id INT NOT NULL,
        user_id INT NOT NULL,
        answers JSON NOT NULL,
        score INT DEFAULT NULL,
        max_score INT NOT NULL,
        status ENUM('submitted', 'graded') DEFAULT 'submitted',
        submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (exercise_id) REFERENCES exercises(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Grades table
    $mysqli->query("CREATE TABLE IF NOT EXISTS grades (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        course_id INT NOT NULL,
        exercise_id INT DEFAULT NULL,
        score DECIMAL(5, 2) NOT NULL,
        max_score DECIMAL(5, 2) DEFAULT 100,
        grade_type ENUM('exercise', 'assignment', 'midterm', 'final') DEFAULT 'exercise',
        feedback TEXT,
        submitted_by INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
        FOREIGN KEY (exercise_id) REFERENCES exercises(id) ON DELETE SET NULL,
        FOREIGN KEY (submitted_by) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Files/Documents table (for DOCX, PDF, PPTX uploads)
    $mysqli->query("CREATE TABLE IF NOT EXISTS file_uploads (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        course_id INT NOT NULL,
        file_name VARCHAR(255) NOT NULL,
        file_path VARCHAR(255) NOT NULL,
        file_type ENUM('pdf', 'docx', 'pptx', 'video', 'other') DEFAULT 'other',
        file_size INT NOT NULL,
        upload_purpose ENUM('material', 'assignment', 'submission', 'resource') DEFAULT 'material',
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Videos table
    $mysqli->query("CREATE TABLE IF NOT EXISTS videos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        course_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        video_url VARCHAR(500) NOT NULL,
        instructor_id INT NOT NULL,
        duration_minutes INT DEFAULT NULL,
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
        FOREIGN KEY (instructor_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Schedules table
    $mysqli->query("CREATE TABLE IF NOT EXISTS schedules (
        id INT AUTO_INCREMENT PRIMARY KEY,
        course_id INT NOT NULL,
        instructor_id INT NOT NULL,
        schedule_date DATE NOT NULL,
        start_time TIME NOT NULL,
        end_time TIME NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        location_or_link VARCHAR(255),
        schedule_type ENUM('lecture', 'lab', 'assignment', 'exam', 'office_hours') DEFAULT 'lecture',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
        FOREIGN KEY (instructor_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Insert default admin/instructor accounts when none exist
    $result = $mysqli->query("SELECT COUNT(*) AS total, SUM(role = 'admin' OR role = 'instructor') AS privileged FROM users");
    if ($result) {
        $stats = $result->fetch_assoc();
        $result->free();
        if (intval($stats['privileged']) === 0) {
            $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
            $instructorPassword = password_hash('instructor123', PASSWORD_DEFAULT);
            $stmt = $mysqli->prepare('INSERT INTO users (name, email, password, role, is_admin) VALUES (?, ?, ?, ?, ?)');
            if ($stmt) {
                $adminName = 'Borana Admin';
                $adminEmail = 'admin@borana.edu';
                $role = 'admin';
                $isAdmin = 1;
                $stmt->bind_param('ssssi', $adminName, $adminEmail, $adminPassword, $role, $isAdmin);
                $stmt->execute();

                $instructorName = 'Lead Instructor';
                $instructorEmail = 'instructor@borana.edu';
                $role = 'instructor';
                $isAdmin = 0;
                $stmt->bind_param('ssssi', $instructorName, $instructorEmail, $instructorPassword, $role, $isAdmin);
                $stmt->execute();

                $stmt->close();
            }
        }
    }

    // Optional: enable simple search index on courses (may be skipped on older MySQL)
    // Gracefully ignore failures
    @$mysqli->query("ALTER TABLE courses ADD FULLTEXT INDEX ft_courses_title_description (title, description)");
}
