<?php
require_once __DIR__ . '/../auth.php';
require_instructor();
require_once __DIR__ . '/../db.php';

$lessons = [];
$result = $mysqli->query("SELECT l.*, c.title AS course_title FROM lessons l LEFT JOIN courses c ON l.course_id = c.id ORDER BY l.created_at DESC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $lessons[] = $row;
    }
    $result->free();
}

$title = 'My Lessons';
$page = 'instructor';
include __DIR__ . '/../includes/header.php';
?>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 class="mb-4">My Lessons</h1>
                    <a href="../admin/upload_material.php" class="btn btn-success mb-3">Create New Lesson</a>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Course</th>
                                    <th>Material</th>
                                    <th>Video</th>
                                    <th>Created</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($lessons as $lesson): ?>
                                    <tr>
                                        <td><?= $lesson['id'] ?></td>
                                        <td><?= htmlspecialchars($lesson['title']) ?></td>
                                        <td><?= htmlspecialchars($lesson['course_title'] ?? '—') ?></td>
                                        <td><?php if (!empty($lesson['material_file'])): ?>
                                            <a href="<?= '../' . MATERIALS_PATH . '/' . $lesson['material_file'] ?>" target="_blank">Download</a>
                                        <?php else: ?>—<?php endif; ?></td>
                                        <td><?= $lesson['video_url'] ? '<a href="' . htmlspecialchars($lesson['video_url']) . '" target="_blank">View</a>' : '—' ?></td>
                                        <td><?= $lesson['created_at'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include __DIR__ . '/../includes/footer.php';
