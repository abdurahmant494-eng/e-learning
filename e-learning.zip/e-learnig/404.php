<?php
$page = '404';
$title = '404 Page Not Found';
include 'includes/header.php';
?>

    <div class="container-xxl py-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center">
            <h1 class="display-1 text-primary">404</h1>
            <h1 class="mb-4">Page Not Found</h1>
            <p class="mb-4">The page you are looking for does not exist or has been moved.</p>
            <a class="btn btn-primary py-3 px-5" href="index.php">Back To Home</a>
        </div>
    </div>

<?php include 'includes/footer.php'; ?>
