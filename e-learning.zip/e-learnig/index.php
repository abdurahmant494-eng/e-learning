<?php
$page = 'home';
$title = 'Home';
require_once 'db.php';
$courses = [];
if ($mysqli) {
    $result = $mysqli->query("SELECT * FROM courses ORDER BY id DESC LIMIT 3");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $courses[] = $row;
        }
        $result->free();
    }
}
if (empty($courses)) {
    $courses = [
        [
            'title' => 'Web Design & Development Course for Beginners',
            'description' => 'Learn modern web design and development using HTML, CSS, JavaScript, and Bootstrap.',
            'price' => '$149.00',
            'teacher' => 'Yasin A.',
            'duration' => '1.49 Hrs',
            'students' => '30 Students',
            'image' => 'course-1.JPEG',
        ],
        [
            'title' => 'Digital Marketing Mastery',
            'description' => 'Master SEO, social media marketing, and campaign analytics.',
            'price' => '$139.00',
            'teacher' => 'Boru Guyo',
            'duration' => '1.35 Hrs',
            'students' => '39 Students',
            'image' => 'course-3.JPEG',
        ],
        [
            'title' => 'UI/UX Design Bootcamp',
            'description' => 'Design powerful user experiences and interfaces with real-world projects.',
            'price' => '$129.00',
            'teacher' => 'Abraham T.',
            'duration' => '2.10 Hrs',
            'students' => '43 Students',
            'image' => 'course-2.JPEG',
        ],
    ];
}
include 'includes/header.php';
?>

    <!-- Hero Start -->
    <div class="container-fluid p-0 mb-5">
        <div class="owl-carousel header-carousel position-relative">
            <div class="owl-carousel-item position-relative">
                <img class="img-fluid" src="<?= IMG_PATH ?>/carousel-1.JPEG" alt="">
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style="background: rgba(24, 29, 56, 0);">
                    <div class="container">
                        <div class="hero-caption">
                            <div class="caption-inner">
                                <div class="row justify-content-start">
                                    <div class="col-sm-10 col-lg-8">
                                        <div class="caption-text">
                                            <h5 class="text-uppercase mb-3 animated slideInDown">Best Online Courses</h5>
                                            <h1 class="display-3 animated slideInDown">The Best Online Learning Platform</h1>
                                            <p class="fs-5 mb-4 pb-2">Build the skills you need with flexible online classes and expert instructors.</p>
                                        </div>
                                        <a href="about.php" class="btn btn-primary py-md-3 px-md-5 me-3 animated slideInLeft">Read More</a>
                                        <a href="contact.php" class="btn btn-light py-md-3 px-md-5 animated slideInRight">Join Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="owl-carousel-item position-relative">
                <img class="img-fluid" src="<?= IMG_PATH ?>/carousel-2.JPEG" alt="">
                <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center" style="background: rgba(24, 29, 56, 0);">
                    <div class="container">
                        <div class="hero-caption">
                            <div class="caption-inner">
                                <div class="row justify-content-start">
                                    <div class="col-sm-10 col-lg-8">
                                        <div class="caption-text">
                                            <h5 class="text-uppercase mb-3 animated slideInDown">Best Online Courses</h5>
                                            <h1 class="display-3 animated slideInDown">Get Educated Online From Your Home</h1>
                                            <p class="fs-5 mb-4 pb-2">Flexible learning that fits your schedule with expert-led training.</p>
                                        </div>
                                        <a href="about.php" class="btn btn-primary py-md-3 px-md-5 me-3 animated slideInLeft">Read More</a>
                                        <a href="contact.php" class="btn btn-light py-md-3 px-md-5 animated slideInRight">Join Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Hero End -->

    <!-- Service Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-graduation-cap text-primary mb-4"></i>
                            <h5 class="mb-3">Skilled Instructors</h5>
                            <p>Learn from industry experts and hands-on mentors.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-globe text-primary mb-4"></i>
                            <h5 class="mb-3">Online Classes</h5>
                            <p>Attend classes from anywhere with a modern learning platform.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-home text-primary mb-4"></i>
                            <h5 class="mb-3">Home Projects</h5>
                            <p>new project will coming soon</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="service-item text-center pt-3">
                        <div class="p-4">
                            <i class="fa fa-3x fa-book-open text-primary mb-4"></i>
                            <h5 class="mb-3">Book Library</h5>
                            <p>Access curated resources and learning materials anytime.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Service End -->

    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <img class="img-fluid position-absolute w-100 h-100" src="<?= IMG_PATH ?>/about.jpg" alt="" style="object-fit: cover;">
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <h6 class="section-title bg-white text-start text-primary pe-3">About Us</h6>
                    <h1 class="mb-4">Welcome to Borana University eLEARNING</h1>
                    <p class="mb-4">Get access to high-quality online courses created by experienced instructors and professionals.</p>
                    <p class="mb-4">Our platform makes it easy to learn new skills, improve your career, and stay connected through modern online learning tools.</p>
                    <div class="row gy-2 gx-4 mb-4">
                        <div class="col-sm-6"><p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Skilled Instructors</p></div>
                        <div class="col-sm-6"><p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Online Classes</p></div>
                        <div class="col-sm-6"><p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>International Certificate</p></div>
                        <div class="col-sm-6"><p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Live Support</p></div>
                    </div>
                    <a class="btn btn-primary py-3 px-5 mt-2" href="about.php">Read More</a>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->

    <!-- Courses Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Courses</h6>
                <h1 class="mb-5">Popular Courses</h1>
            </div>
            <div class="row g-4 justify-content-center">
                <?php foreach ($courses as $course): ?>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="course-item bg-light">
                        <div class="position-relative overflow-hidden">
                            <img class="img-fluid" src="<?= IMG_PATH ?>/<?= htmlspecialchars($course['image']) ?>" alt="">
                            <div class="w-100 d-flex justify-content-center position-absolute bottom-0 start-0 mb-4">
                                <a href="contact.php" class="flex-shrink-0 btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 0 0 30px;">Read More</a>
                                <a href="contact.php" class="flex-shrink-0 btn btn-sm btn-primary px-3" style="border-radius: 0 30px 30px 0;">Join Now</a>
                            </div>
                        </div>
                        <div class="text-center p-4 pb-0">
                            <h3 class="mb-0"><?= htmlspecialchars($course['price']) ?></h3>
                            <div class="mb-3">
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small>(123)</small>
                            </div>
                            <h5 class="mb-4"><?= htmlspecialchars($course['title']) ?></h5>
                            <p><?= htmlspecialchars($course['description']) ?></p>
                        </div>
                        <div class="d-flex border-top">
                            <small class="flex-fill text-center border-end py-2"><i class="fa fa-user-tie text-primary me-2"></i><?= htmlspecialchars($course['teacher']) ?></small>
                            <small class="flex-fill text-center border-end py-2"><i class="fa fa-clock text-primary me-2"></i><?= htmlspecialchars($course['duration']) ?></small>
                            <small class="flex-fill text-center py-2"><i class="fa fa-user text-primary me-2"></i><?= htmlspecialchars($course['students']) ?></small>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="text-center mt-4">
                <a href="courses.php" class="btn btn-primary py-3 px-5">View All Courses</a>
            </div>
        </div>
    </div>
    <!-- Courses End -->

    <!-- Team Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Instructors</h6>
                <h1 class="mb-5">Expert Instructors</h1>
            </div>
            <div class="row g-4">
                <?php foreach (['team-1.jpg','team-2.jpg','team-3.jpg','team-4.jpg'] as $teamImage): ?>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="<?= IMG_PATH ?>/<?= $teamImage ?>" alt="">
                        </div>
                        <div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">
                            <div class="bg-light d-flex justify-content-center pt-2 px-1">
                                <a class="btn btn-sm-square btn-primary mx-1" href="#"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href="#"><i class="fab fa-twitter"></i></a>
                                <a class="btn btn-sm-square btn-primary mx-1" href="#"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="text-center p-4">
                            <h5 class="mb-0">Instructor Name</h5>
                            <small> Sample Designation</small>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <!-- Team End -->

    <!-- Footer and scripts -->
<?php include 'includes/footer.php'; ?>
