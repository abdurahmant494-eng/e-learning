<?php
$page = 'courses';
$title = 'Courses';
require_once 'auth.php';
require_login();

function ensure_sample_courses_exist($mysqli) {
    $courseTemplates = [
        [
            'title' => 'Design and Analysis of Algorithms',
            'description' => 'Master algorithm design, complexity, and data structures using core academic material.',
            'teacher' => 'WCMC Faculty',
            'duration' => 'Self-paced',
            'students' => '1 Lesson',
            'image' => 'course-1.jpg',
            'lessons' => [
                [
                    'title' => 'Design and Analysis of Algorithms',
                    'content' => 'Study algorithm design and analysis, including complexity and data structures.',
                    'material' => 'Introduction_to_the_Design_and_Analysis_of_Algorithms_FTP_Directory.pdf',
                    'sort_order' => 1,
                ],
            ],
        ],
        [
            'title' => 'Artificial Intelligence Fundamentals',
            'description' => 'Explore AI theory and practical approaches from a leading textbook.',
            'teacher' => 'WCMC Faculty',
            'duration' => 'Self-paced',
            'students' => '1 Lesson',
            'image' => 'course-2.jpg',
            'lessons' => [
                [
                    'title' => 'Artificial Intelligence Fundamentals',
                    'content' => 'Explore artificial intelligence concepts, search, learning, and reasoning techniques.',
                    'material' => 'Artificial_Intelligence_A_Modern_Approach_3rd_Edition_pdf_PDFDrive.pdf',
                    'sort_order' => 1,
                ],
            ],
        ],
        [
            'title' => 'Computer Science Exam Practice',
            'description' => 'Practice with real exam questions and answers to evaluate your CS knowledge.',
            'teacher' => 'WCMC Faculty',
            'duration' => 'Self-paced',
            'students' => '1 Lesson',
            'image' => 'course-3.jpg',
            'lessons' => [
                [
                    'title' => 'Computer Science Exam Practice',
                    'content' => 'Work through exam-style questions and answers to reinforce understanding.',
                    'material' => 'Computer Science Exit Exam 2018 with Answer.pdf',
                    'sort_order' => 1,
                ],
            ],
        ],
        [
            'title' => 'Introduction to Operating Systems',
            'description' => 'Learn the fundamentals of operating systems, processes, and memory management.',
            'teacher' => 'WCMC Faculty',
            'duration' => 'Self-paced',
            'students' => '1 Lesson',
            'image' => 'course-1.jpg',
            'lessons' => [
                [
                    'title' => 'Introduction to Operating Systems',
                    'content' => 'Understand processes, threads, scheduling, and operating system architecture.',
                    'material' => 'INTRODUCTION_TO_OPERATING_SYSTEM.pdf',
                    'sort_order' => 1,
                ],
            ],
        ],
        [
            'title' => 'Digital Marketing Mastery',
            'description' => 'Learn SEO, social media marketing, and campaign analytics through blog-style lessons inspired by top online learning sites.',
            'teacher' => 'Industry Expert',
            'duration' => '4 Lessons',
            'students' => '55 Students',
            'image' => 'course-3.jpg',
            'lessons' => [
                [
                    'title' => 'SEO Foundations',
                    'content' => "Start with search engine optimization basics: keyword research, on-page SEO, and how to structure content for discoverability. Learn practical steps to make your content rank higher and attract organic traffic.",
                    'material' => '',
                    'sort_order' => 1,
                ],
                [
                    'title' => 'Social Media Strategy',
                    'content' => "Build a social media plan that works across Instagram, Facebook, LinkedIn, and TikTok. Discover how to plan campaigns, craft shareable posts, and measure engagement with real examples.",
                    'material' => '',
                    'sort_order' => 2,
                ],
                [
                    'title' => 'Content Marketing & Blogging',
                    'content' => "Create blog content and digital stories that attract readers and convert them into followers. Learn best practices for blog structure, headlines, meta descriptions, and evergreen content.",
                    'material' => '',
                    'sort_order' => 3,
                ],
                [
                    'title' => 'Analytics and Conversion',
                    'content' => "Use analytics tools to track campaign performance, improve conversions, and optimize your ad spend. Learn how to set goals, read dashboards, and turn data into better marketing decisions.",
                    'material' => '',
                    'sort_order' => 4,
                ],
            ],
        ],
        [
            'title' => 'Blog-Style Content Strategy',
            'description' => 'A blog-like learning course on content strategy, branding, and digital storytelling.',
            'teacher' => 'Knowledge Partner',
            'duration' => '3 Lessons',
            'students' => '42 Students',
            'image' => 'course-2.jpg',
            'lessons' => [
                [
                    'title' => 'Planning Your Content Calendar',
                    'content' => "Learn how successful blogs and online learning sites organize content. Plan your editorial calendar, choose themes, and keep your audience engaged with consistent publishing.",
                    'material' => '',
                    'sort_order' => 1,
                ],
                [
                    'title' => 'Writing Engaging Articles',
                    'content' => "Discover the structure of great blog posts, effective headline formulas, and the storytelling techniques that make technical content feel approachable. Practice creating clear sections and strong calls-to-action.",
                    'material' => '',
                    'sort_order' => 2,
                ],
                [
                    'title' => 'Growing an Audience',
                    'content' => "Use SEO, social sharing, and community-building to grow your readership. Learn proven tips for promoting blog content and turning visitors into returning learners.",
                    'material' => '',
                    'sort_order' => 3,
                ],
            ],
        ],
    ];

    // Remove the old combined WCMC course if it exists.
    $deleteOld = $mysqli->prepare("DELETE FROM courses WHERE title = ?");
    if ($deleteOld) {
        $oldTitle = 'WCMC Computer Science Mastery';
        $deleteOld->bind_param('s', $oldTitle);
        $deleteOld->execute();
        $deleteOld->close();
    }

    foreach ($courseTemplates as $courseData) {
        $courseId = 0;
        $stmt = $mysqli->prepare("SELECT id FROM courses WHERE title = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('s', $courseData['title']);
            $stmt->execute();
            $stmt->bind_result($courseId);
            $stmt->fetch();
            $stmt->close();
        }

        if (!$courseId) {
            $insert = $mysqli->prepare(
                "INSERT INTO courses (title, description, price, teacher, duration, students, image) VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            if ($insert) {
                $price = 'Free';
                $insert->bind_param(
                    'sssssss',
                    $courseData['title'],
                    $courseData['description'],
                    $price,
                    $courseData['teacher'],
                    $courseData['duration'],
                    $courseData['students'],
                    $courseData['image']
                );
                $insert->execute();
                $courseId = $insert->insert_id;
                $insert->close();
            }
        }

        if ($courseId && !empty($courseData['lessons'])) {
            foreach ($courseData['lessons'] as $lessonData) {
                $lessonId = 0;
                $lessonQuery = $mysqli->prepare("SELECT id FROM lessons WHERE course_id = ? AND title = ? LIMIT 1");
                if ($lessonQuery) {
                    $lessonQuery->bind_param('is', $courseId, $lessonData['title']);
                    $lessonQuery->execute();
                    $lessonQuery->bind_result($lessonId);
                    $lessonQuery->fetch();
                    $lessonQuery->close();
                }

                if (!$lessonId) {
                    $insertLesson = $mysqli->prepare(
                        "INSERT INTO lessons (course_id, title, content, video_url, material_file, sort_order) VALUES (?, ?, ?, '', ?, ?)"
                    );
                    if ($insertLesson) {
                        $materialFile = $lessonData['material'] ?: null;
                        $sortOrder = $lessonData['sort_order'] ?? 1;
                        $insertLesson->bind_param(
                            'isssi',
                            $courseId,
                            $lessonData['title'],
                            $lessonData['content'],
                            $materialFile,
                            $sortOrder
                        );
                        $insertLesson->execute();
                        $insertLesson->close();
                    }
                }
            }
        }
    }
}

ensure_sample_courses_exist($mysqli);

$courses = [];
if ($mysqli) {
    $stmt = $mysqli->prepare(
        "SELECT c.*, COUNT(l.id) AS total_lessons,
            IFNULL(SUM(p.completed), 0) AS completed_lessons,
            IFNULL(SUM(CASE WHEN p.lesson_id IS NOT NULL THEN 1 ELSE 0 END), 0) AS started_lessons
         FROM courses c
         LEFT JOIN lessons l ON l.course_id = c.id
         LEFT JOIN progress p ON p.lesson_id = l.id AND p.user_id = ?
         GROUP BY c.id
         ORDER BY c.id DESC"
    );
    if ($stmt) {
        $stmt->bind_param('i', $_SESSION['user']['id']);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $row['progress_percent'] = $row['total_lessons'] ? intval(($row['completed_lessons'] / $row['total_lessons']) * 100) : 0;
            $courses[] = $row;
        }
        $stmt->close();
    }
}
if (empty($courses)) {
    $courses = [
        [
            'id' => 0,
            'title' => 'Web Design & Development Course for Beginners',
            'description' => 'Learn modern web design and development using HTML, CSS, JavaScript, and Bootstrap.',
            'price' => '$149.00',
            'teacher' => 'John Doe',
            'duration' => '1.49 Hrs',
            'students' => '30 Students',
            'image' => 'course-1.jpg',
        ],
        [
            'id' => 0,
            'title' => 'Digital Marketing Mastery',
            'description' => 'Master SEO, social media marketing, and campaign analytics.',
            'price' => '$139.00',
            'teacher' => 'Lisa Brown',
            'duration' => '1.35 Hrs',
            'students' => '39 Students',
            'image' => 'course-3.jpg',
        ],
        [
            'id' => 0,
            'title' => 'UI/UX Design Bootcamp',
            'description' => 'Design powerful user experiences and interfaces with real-world projects.',
            'price' => '$129.00',
            'teacher' => 'Jane Smith',
            'duration' => '2.10 Hrs',
            'students' => '43 Students',
            'image' => 'course-2.jpg',
        ],
    ];
}
include 'includes/header.php';
?>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Courses</h6>
                <h1 class="mb-5">Browse Our Courses</h1>
            </div>
            <div class="row g-4 justify-content-center">
                <?php foreach ($courses as $course): ?>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="course-item bg-light">
                        <div class="position-relative overflow-hidden">
                            <img class="img-fluid" src="<?= IMG_PATH ?>/<?= htmlspecialchars($course['image']) ?>" alt="">
                            <div class="w-100 d-flex justify-content-center position-absolute bottom-0 start-0 mb-4">
                                <a href="course.php?id=<?= $course['id'] ?>" class="flex-shrink-0 btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 0 0 30px;">Read More</a>
                                <a href="course.php?id=<?= $course['id'] ?>" class="flex-shrink-0 btn btn-sm btn-primary px-3" style="border-radius: 0 30px 30px 0;">
                                    <?= (!empty($course['started_lessons']) ? 'Resume Course' : 'Start Course') ?>
                                </a>
                            </div>
                        </div>
                        <div class="text-center p-4 pb-0">
                            <h3 class="mb-0"><?= htmlspecialchars($course['price']) ?></h3>
                            <div class="mb-3">
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small>(123)</small>
                            </div>
                            <h5 class="mb-4"><?= htmlspecialchars($course['title']) ?></h5>
                            <p><?= htmlspecialchars($course['description']) ?></p>
                            <?php if (!empty($course['total_lessons'])): ?>
                                <div class="mb-3 text-start">
                                    <small class="text-muted">Progress: <?= $course['completed_lessons'] ?> / <?= $course['total_lessons'] ?> lessons</small>
                                    <div class="progress mt-1" style="height: 10px;">
                                        <div class="progress-bar" role="progressbar" style="width: <?= $course['progress_percent'] ?>%;" aria-valuenow="<?= $course['progress_percent'] ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="d-flex border-top">
                            <small class="flex-fill text-center border-end py-2"><i class="fa fa-user-tie text-primary me-2"></i><?= htmlspecialchars($course['teacher']) ?></small>
                            <small class="flex-fill text-center border-end py-2"><i class="fa fa-clock text-primary me-2"></i><?= htmlspecialchars($course['duration']) ?></small>
                            <small class="flex-fill text-center py-2"><i class="fa fa-user text-primary me-2"></i><?= htmlspecialchars($course['students']) ?></small>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

<?php include 'includes/footer.php'; ?>
