# eLearning PHP + MySQL Conversion

## Setup with XAMPP
1. Copy this folder to your XAMPP `htdocs` directory, for example: `C:\xampp\htdocs\e-learnig`.
2. Start Apache and MySQL in XAMPP control panel.
3. Open `http://localhost/phpmyadmin`.
4. Import `database.sql`.
5. Open `http://localhost/e-learnig/index.php` in your browser.

### One-click launch
- If you are on Windows, double-click `run_elearning.bat` from the project root.
- This will start Apache and MySQL via XAMPP’s startup scripts and open your browser.

## Notes
- The app uses `root` with no password for local XAMPP.
- Contact form submissions are stored in the `contact_messages` table.
- Course cards are served from the `courses` table if the database is available.

## Important
- Do not rename the downloaded asset folders manually. The PHP code uses the current timestamped folder names as asset paths.
