# Borana University E-Learning System - Features Documentation

## Project Overview
A comprehensive web-based e-learning platform for Borana University with role-based access control, course management, exercise modules, and grade tracking.

---

## 1. USER ROLES & ACCESS CONTROL

### 1.1 **ADMIN** Role
- **Account Management**: Create, edit, and deactivate user accounts
- **Department Management**: Create and manage university departments
- **Course Management**: Create, edit, publish, and archive courses
- **Schedule Posting**: Set academic schedules and important dates
- **User Permissions**: Assign instructor and student roles to users
- **System Oversight**: View system analytics and user activity

### 1.2 **INSTRUCTOR** Role
- **Material Upload**: Upload course materials (PDF, DOCX, PPTX)
- **Video Upload**: Add video lectures to courses
- **Exercise Creation**: Design and publish quizzes and exercises
- **Grade Management**: Upload grades and provide feedback to students
- **Schedule Management**: Post class schedules, office hours, and exam dates
- **Student Monitoring**: View student submissions and track progress
- **Announcement**: Send class announcements and notifications

### 1.3 **STUDENT** Role
- **Resource Download**: Download course materials and video lectures
- **Exercise Participation**: Take quizzes and submit exercises
- **Grade Viewing**: View submitted grades and instructor feedback
- **Schedule Viewing**: Check class timetables, assignment deadlines, and exam dates
- **Progress Tracking**: Monitor course completion percentage
- **Certificate Viewing**: Download completion certificates
- **Course Enrollment**: Join available courses

---

## 2. CORE SYSTEM FEATURES

### 2.1 Authentication & Session Management ✅
**Feature Description:**
- Secure login with email and password validation
- Password hashing using PHP's password_hash()
- Session management with timeout protection
- Role-based session tracking
- Logout functionality

**File Location:** `login.php`, `logout.php`, `signup.php`, `auth.php`

**Database Table:** `users`
- Supports: student, instructor, admin roles
- Includes: avatar, department affiliation

---

### 2.2 Department Management ✅ (NEW)
**Feature Description:**
- Create new academic departments
- Assign department heads (instructors/admins)
- View all departments and their instructors
- Delete departments (with cascade to courses)
- Manage department course offerings

**Database Table:** `departments`
- Fields: id, name, description, head_id, created_at

**Workflow:**
1. Admin creates department
2. Admin assigns head
3. Courses are linked to departments
4. Instructors view their department courses

---

### 2.3 Course Management ✅
**Feature Description:**
- Create new courses with title, description, duration
- Assign instructor to course
- Link course to department
- Upload course cover image
- Set course price/status (free/paid)
- View course statistics
- Archive/delete courses
- Enroll students in courses

**Database Table:** `courses`

**Admin Interface:** `admin/index.php`

---

### 2.4 Lesson Management ✅
**Feature Description:**
- Create multiple lessons per course
- Organize lessons with sort order
- Add lesson content (text/rich text)
- Link PDF materials to lessons
- Embed video URLs
- Track lesson completion by students

**Database Table:** `lessons`

**Features:**
- Lessons displayed in sidebar navigation
- Progress indicators (Done/In Progress/Pending)
- Next lesson suggestion
- Material viewer with full-screen option

**Admin Interface:** `admin/lessons.php`, `admin/edit_lesson.php`, `admin/upload_material.php`

---

### 2.5 File Upload Management ✅ (NEW)
**Feature Description:**
- Support for PDF, DOCX, PPTX file types
- Validate file types before upload
- File size restrictions (configurable)
- Secure file naming to prevent overwrite
- File organization by course
- Track uploaded files with metadata

**Supported Formats:**
- PDF (Portable Document Format)
- DOCX (Microsoft Word)
- PPTX (Microsoft PowerPoint)

**Database Table:** `file_uploads`
- Fields: id, user_id, course_id, file_name, file_path, file_type, file_size, upload_purpose, uploaded_at

**File Upload Validation:**
```php
$allowed_types = ['pdf', 'docx', 'pptx'];
$max_file_size = 50 * 1024 * 1024; // 50MB
```

**Upload Paths:**
- Materials: `/uploads/materials/`
- Avatars: `/uploads/avatars/`
- Resources: `/uploads/resources/`

---

### 2.6 Video Management ✅ (NEW)
**Feature Description:**
- Add video lectures to courses
- Support for embedded video URLs (YouTube, Vimeo, etc.)
- Video metadata (title, description, duration)
- Associate videos with specific lessons
- Track video viewing (optional)

**Database Table:** `videos`
- Fields: id, course_id, title, description, video_url, instructor_id, duration_minutes, uploaded_at

**Features:**
- Embed external video players
- Video upload delegation (use existing video hosting)
- Video metadata search

---

### 2.7 Exercise/Quiz Module ✅ (NEW)
**Feature Description:**
- Create multiple-choice exercises and quizzes
- Store questions in JSON format
- Set passing score requirements
- Limit attempt attempts per student
- Provide immediate feedback after submission
- Track student performance

**Database Tables:**
1. `exercises`: Quiz/exercise definitions
   - Fields: id, course_id, title, description, questions, passing_score, attempts_allowed, instructor_id
   
2. `exercise_submissions`: Student answers and scores
   - Fields: id, exercise_id, user_id, answers, score, max_score, status, submitted_at

**Exercise Structure:**
```json
{
  "questions": [
    {
      "id": 1,
      "type": "multiple_choice",
      "text": "Question text?",
      "options": ["A", "B", "C", "D"],
      "correct_answer": "B",
      "points": 10
    }
  ]
}
```

**Workflow:**
1. Instructor creates exercise with questions
2. Student takes exercise
3. System auto-calculates score based on correct answers
4. Results display immediately with feedback
5. Grade recorded in grades table

---

### 2.8 Grading System ✅ (NEW)
**Feature Description:**
- Record grades for exercises, assignments, exams
- Support multiple grade types (exercise, assignment, midterm, final)
- Grade calculation from exercise submissions
- Instructor feedback on grades
- Grade distribution statistics
- Student grade viewing
- GPA/performance tracking

**Database Table:** `grades`
- Fields: id, user_id, course_id, exercise_id, score, max_score, grade_type, feedback, submitted_by, created_at

**Grade Types:**
- Exercise (auto-calculated from submissions)
- Assignment (manual entry by instructor)
- Midterm (manual entry)
- Final (manual entry)

**Features:**
- Grade aggregation per course
- Performance analytics
- Grade histogram for instructor
- Individual grade reports for students

---

### 2.9 Schedule Management ✅ (NEW)
**Feature Description:**
- Create class schedules (lectures, labs, exams)
- Set schedule dates and times
- Specify location/meeting link
- Include description and notes
- Categorize by type (lecture, exam, office hours, etc.)
- Student calendar view
- Email notifications for schedule changes

**Database Table:** `schedules`
- Fields: id, course_id, instructor_id, schedule_date, start_time, end_time, title, description, location_or_link, schedule_type

**Schedule Types:**
- Lecture
- Lab
- Assignment (Due date)
- Exam
- Office Hours

**Display Interfaces:**
- Calendar view for students
- List view by course
- Instructor schedule management
- Notification system

---

### 2.10 Progress Tracking ✅
**Feature Description:**
- Track lesson completion by students
- Calculate course progress percentage
- Display progress visually (progress bars, badges)
- Show next recommended lesson
- Track time spent on lessons
- Identify struggling students

**Database Table:** `progress`

**Dashboard Display:**
- Overall course progress
- Lesson completion status
- Performance metrics
- Comparison with class average

---

### 2.11 Certificate Generation ✅ (PARTIAL)
**Feature Description:**
- Generate certificates upon course completion
- Customize certificate templates
- Include student name, course title, completion date
- Digital download option
- Digital verification code

**Database Table:** `certificates`

**Features:**
- Automatic certificate generation when course is 100% complete
- PDF certificate generation (requires TCPDF or similar)
- Certificate customization with branding

---

### 2.12 User Profile Management ✅
**Feature Description:**
- View user profile with avatar
- Upload profile picture
- Edit user information
- View enrollment history
- View completed courses
- View earned certificates
- Display role badges

**Features:**
- Avatar upload and cropping
- Department affiliation display
- Performance summary
- Course completion timeline

---

### 2.13 Search Functionality ⏳ (PLANNED)
**Feature Description:**
- Search courses by title and description
- Search students by name
- Search instructors by name and department
- Filter by department, course type
- Full-text search with relevance ranking

**Implementation:**
- Use MySQL FULLTEXT INDEX on courses table
- Autocomplete suggestions
- Advanced search filters

---

## 3. DATABASE SCHEMA

### Tables Overview
| Table | Purpose | Status |
|-------|---------|--------|
| users | User accounts with roles | ✅ Complete |
| departments | Academic departments | ✅ Complete |
| courses | Course definitions | ✅ Complete |
| lessons | Course lessons/modules | ✅ Complete |
| exercises | Quizzes and exercises | ✅ Complete |
| exercise_submissions | Student exercise answers | ✅ Complete |
| grades | Student grades/scores | ✅ Complete |
| file_uploads | Uploaded files tracking | ✅ Complete |
| videos | Video lectures | ✅ Complete |
| schedules | Class schedules | ✅ Complete |
| progress | Lesson completion tracking | ✅ Complete |
| comments | Course discussions | ✅ Complete |
| certificates | Course completion certificates | ✅ Complete |
| contact_messages | Contact form submissions | ✅ Complete |

---

## 4. SECURITY FEATURES

### 4.1 Authentication Security
- Password hashing with `password_hash()`
- Prepared statements for SQL injection prevention
- Session token validation
- CSRF protection (via session-based tokens)

### 4.2 File Upload Security
- File type validation (whitelist: PDF, DOCX, PPTX)
- File size limits (50MB default)
- Prevent script execution in upload directories
- Random filename generation to prevent collisions

### 4.3 Role-Based Access Control
- Check user role before allowing actions
- Page-level access control
- Endpoint validation for role permissions
- Admin-only operations protected

### 4.4 Input Validation
- Required field validation
- Email format validation
- HTML escape output to prevent XSS
- Length limits on text fields

---

## 5. ERROR HANDLING & VALIDATION

### 5.1 Login Validation
- Empty email/password checks ❌ IMPLEMENT
- Invalid email format checks ❌ IMPLEMENT
- Incorrect password feedback ❌ IMPLEMENT
- Account lockout after failed attempts ❌ IMPLEMENT

### 5.2 File Upload Validation
- Check file type (must be PDF, DOCX, PPTX) ✅
- Check file size limits ✅
- Check for malicious file extensions ✅
- Display user-friendly error messages ❌ ENHANCE

### 5.3 Form Validation
- Required field checks ✅
- Email uniqueness check ✅
- Password strength requirements ❌ IMPLEMENT
- Duplicate course name prevention ❌ IMPLEMENT

---

## 6. UI/UX FEATURES

### 6.1 Responsive Design
- Bootstrap 5 framework
- Mobile-first approach
- Tablet and desktop optimization
- Touch-friendly buttons and inputs

### 6.2 Navigation
- Header with role-based menu items
- Footer with quick links
- Sidebar for admin features
- Breadcrumb navigation

### 6.3 Course Interface
- Course grid/list view
- Course detail with progress bar
- Collapsible lesson sidebar (Udacity-style)
- Module badges (Done/In Progress/Pending)
- Next lesson recommendation box

### 6.4 Admin Dashboard
- Quick stats (total courses, students, instructors)
- Recent activities
- Department management interface
- User management interface
- Course management interface

---

## 7. IMPLEMENTATION STATUS SUMMARY

### Completed ✅
- User authentication and roles
- Course management
- Lesson management
- File upload (PDF materials)
- Progress tracking
- Admin panel (basic)
- User profiles with avatars
- Database schema (all tables)
- Responsive UI with Bootstrap

### In Progress ⏳
- Exercise submission and grading
- Schedule management interface
- Department management interface
- Video integration

### Planned ❌
- Certificate generation (PDF)
- Advanced search
- Email notifications
- Mobile app
- API endpoints
- Analytics dashboard
- Student performance reports
- Instructor dashboard enhancements

---

## 8. FILE STRUCTURE

```
e-learnig/
├── index.php              # Landing page
├── login.php              # Login page
├── signup.php             # Registration page
├── logout.php             # Logout handler
├── courses.php            # Course listing
├── course.php             # Course detail
├── lesson.php             # Lesson viewer
├── profile.php            # User profile
├── auth.php               # Auth helpers
├── db.php                 # Database initialization
├── config.php             # Configuration
├── admin/
│   ├── index.php          # Admin dashboard
│   ├── lessons.php        # Lesson management
│   ├── upload_material.php# Material upload
│   ├── edit_lesson.php    # Lesson editor
│   ├── exercises.php      # Exercise management (PLANNED)
│   ├── grades.php         # Grade management (PLANNED)
│   ├── departments.php    # Department management (PLANNED)
│   └── schedules.php      # Schedule management (PLANNED)
├── uploads/
│   ├── materials/         # Course materials
│   ├── avatars/           # User avatars
│   └── resources/         # Other resources
├── css/
│   └── style.css          # Main stylesheet
├── js/
│   └── main.js            # Client-side scripts
├── includes/
│   ├── header.php         # Page header
│   └── footer.php         # Page footer
└── lib/                   # Third-party libraries
```

---

## 9. FEATURES BY USER ROLE

### ADMIN Dashboard Features
- [x] View all users by role
- [x] Create/edit/delete courses
- [x] Manage departments
- [ ] Create instructor accounts
- [ ] Post university schedules
- [ ] System analytics
- [ ] Backup and maintenance

### INSTRUCTOR Dashboard Features
- [ ] View my courses and students
- [x] Upload materials and videos
- [ ] Create and manage exercises
- [ ] Grade exercises and assign scores
- [ ] Post class schedules
- [ ] View student submissions
- [ ] Send announcements
- [ ] Generate class reports

### STUDENT Dashboard Features
- [x] View enrolled courses
- [x] Access course materials and videos
- [ ] Take quizzes/exercises
- [ ] View my grades
- [x] Track progress per course
- [x] Download certificates
- [x] View class schedule
- [ ] Ask questions/discussion

---

## 10. NEXT STEPS FOR COMPLETION

1. **Implement Exercise Interface** - Create UI for exercise creation and taking
2. **Build Grade Management** - Instructor interface for grades, student view for grades
3. **Develop Schedule Views** - Calendar display for students, management for instructors
4. **Create Department Manager** - Admin interface for department CRUD
5. **Implement Certificates** - PDF generation and download
6. **Add Email Notifications** - Notify students of grades, schedules, deadlines
7. **Enhanced Error Messages** - Friendly validation feedback throughout
8. **Mobile Testing** - Ensure responsive design works on all devices
9. **Security Audit** - Test for SQL injection, XSS, CSRF
10. **Performance Optimization** - Database indexing, query optimization

