<?php
require_once __DIR__ . '/../auth.php';
require_login();
require_student();
$user = current_user();

$title = 'Student Dashboard';
$page = 'student';
include __DIR__ . '/../includes/header.php';
?>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h1 class="mb-3">Welcome back, <?= htmlspecialchars($user['name']) ?>!</h1>
                    <p class="lead">This is your student dashboard. From here you can continue learning, track progress, and access your certificates.</p>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-lg-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <h5 class="card-title">My Courses</h5>
                            <p class="card-text">View the courses you are enrolled in and resume where you left off.</p>
                            <a href="../courses.php" class="btn btn-primary">Browse Courses</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <h5 class="card-title">My Progress</h5>
                            <p class="card-text">Track your lesson completion and stay on top of your learning goals.</p>
                            <a href="../profile.php" class="btn btn-secondary">View Profile</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <h5 class="card-title">Certificates</h5>
                            <p class="card-text">Download certificates for completed courses and share your achievements.</p>
                            <a href="../profile.php" class="btn btn-outline-primary">View Certificates</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row g-4 mt-4">
                <div class="col-lg-6">
                    <div class="card bg-light border-0 shadow-sm h-100">
                        <div class="card-body">
                            <h5 class="card-title">Recommended Courses</h5>
                            <p class="card-text">Explore courses selected for your next skills upgrade.</p>
                            <a href="../courses.php" class="btn btn-primary">Explore Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card bg-light border-0 shadow-sm h-100">
                        <div class="card-body">
                            <h5 class="card-title">Support & Help</h5>
                            <p class="card-text">Need assistance? Contact the Borana University support team for help with your courses.</p>
                            <a href="../contact.php" class="btn btn-secondary">Contact Support</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include __DIR__ . '/../includes/footer.php';
