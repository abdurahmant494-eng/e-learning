<?php
require_once 'auth.php';
redirect_if_logged_in();

$errors = [];
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    if ($password === '') {
        $errors[] = 'Please enter your password.';
    }

    if (empty($errors) && $mysqli) {
        $stmt = $mysqli->prepare('SELECT id, name, email, password, role, avatar, is_admin FROM users WHERE email = ? LIMIT 1');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->bind_result($id, $name, $dbEmail, $hash, $role, $avatar, $is_admin);
        if ($stmt->fetch() && password_verify($password, $hash)) {
            $_SESSION['user'] = [
                'id' => $id,
                'name' => $name,
                'email' => $dbEmail,
                'role' => $role,
                'avatar' => $avatar,
                'is_admin' => $is_admin
            ];
            $stmt->close();
            redirect_to_dashboard();
        }
        $stmt->close();
        $errors[] = 'Email or password is incorrect.';
    }
}

$title = 'Login';
include 'includes/header.php';
?>
<div class="container-xxl py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="p-5 bg-white rounded-4 shadow-sm">
                    <h1 class="mb-4">Welcome back</h1>
                    <div class="alert alert-info">
                        <p class="mb-1"><strong>Presentation demo:</strong> Use the shared login form to access role dashboards.</p>
                        <p class="mb-0"><strong>Admin:</strong> admin@borana.edu / admin123 · <strong>Instructor:</strong> instructor@borana.edu / instructor123</p>
                    </div>
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php foreach ($errors as $error): ?>
                                    <li><?= htmlspecialchars($error) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form method="post" action="login.php">
                        <div class="mb-3">
                            <label class="form-label">Email address</label>
                            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($email) ?>" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-3">Login</button>
                    </form>
                    <p class="mt-4 text-center">Don’t have an account? <a href="signup.php">Create one</a>.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'includes/footer.php';
