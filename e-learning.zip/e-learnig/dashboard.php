<?php
require_once 'auth.php';
redirect_to_dashboard();
