<?php
require_once __DIR__ . '/../auth.php';
require_login();
require_instructor();

$title = 'Instructor Dashboard';
$page = 'instructor';
include __DIR__ . '/../includes/header.php';
?>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 class="mb-4">Instructor Dashboard</h1>
                    <p class="mb-4">Welcome to your teaching dashboard. Manage course lessons, upload materials, and track student progress.</p>
                </div>
            </div>
            <div class="row g-4">
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Create Lesson Content</h5>
                            <p class="card-text">Upload new lesson files, add text content, and keep your course materials fresh.</p>
                            <a href="../admin/upload_material.php" class="btn btn-primary">Upload Material</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Manage Your Lessons</h5>
                            <p class="card-text">Review and edit lessons that you or your team have published.</p>
                            <a href="lessons.php" class="btn btn-secondary">Manage Lessons</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Student Progress</h5>
                            <p class="card-text">Check course progress for your students and follow their completion status.</p>
                            <a href="../courses.php" class="btn btn-outline-primary">View Courses</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Upcoming Features</h5>
                            <p class="card-text">Schedule management, grading tools and live sessions will be available soon.</p>
                            <a href="../profile.php" class="btn btn-outline-secondary">Your Profile</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include __DIR__ . '/../includes/footer.php';
