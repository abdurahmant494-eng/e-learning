<?php
$page = 'testimonial';
$title = 'Testimonial';
require_once 'auth.php';
require_login();
include 'includes/header.php';
?>

    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="text-center">
                <h6 class="section-title bg-white text-center text-primary px-3">Testimonial</h6>
                <h1 class="mb-5">Our Students Say!</h1>
            </div>
            <div class="owl-carousel testimonial-carousel position-relative">
                <?php foreach (range(1, 4) as $index): ?>
                <div class="testimonial-item text-center">
                    <img class="border rounded-circle p-2 mx-auto mb-3" src="<?= IMG_PATH ?>/testimonial-<?= $index ?>.jpg" style="width: 80px; height: 80px;" alt="">
                    <h5 class="mb-0">Client Name</h5>
                    <p>Profession</p>
                    <div class="testimonial-text bg-light text-center p-4">
                        <p class="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos.</p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

<?php include 'includes/footer.php'; ?>
