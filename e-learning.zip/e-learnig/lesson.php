<?php
$page = 'courses';
$title = 'Lesson Details';
require_once 'auth.php';
require_login();
$user = current_user();

$lesson_id = intval($_GET['id'] ?? 0);
if ($lesson_id <= 0) {
    header('Location: courses.php');
    exit;
}

$stmt = $mysqli->prepare(
    "SELECT l.*, c.title AS course_title, c.id AS course_id
     FROM lessons l
     JOIN courses c ON c.id = l.course_id
     WHERE l.id = ? LIMIT 1"
);
$stmt->bind_param('i', $lesson_id);
$stmt->execute();
$lesson = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$lesson) {
    header('Location: courses.php');
    exit;
}

$completed = 0;
$progressStmt = $mysqli->prepare("SELECT completed FROM progress WHERE user_id = ? AND lesson_id = ? LIMIT 1");
$progressStmt->bind_param('ii', $user['id'], $lesson_id);
$progressStmt->execute();
$progressResult = $progressStmt->get_result();
if ($row = $progressResult->fetch_assoc()) {
    $completed = (int) $row['completed'];
}
$progressStmt->close();

$moduleStmt = $mysqli->prepare(
    "SELECT l.*, IFNULL(p.completed, 0) AS completed
     FROM lessons l
     LEFT JOIN progress p ON p.lesson_id = l.id AND p.user_id = ?
     WHERE l.course_id = ?
     ORDER BY l.sort_order ASC, l.id ASC"
);
$moduleStmt->bind_param('ii', $user['id'], $lesson['course_id']);
$moduleStmt->execute();
$modules = $moduleStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$moduleStmt->close();

$nextLesson = null;
foreach ($modules as $module) {
    if ($module['id'] !== $lesson_id && !$module['completed']) {
        $nextLesson = $module;
        break;
    }
}
if ($nextLesson === null) {
    foreach ($modules as $module) {
        if ($module['id'] !== $lesson_id) {
            $nextLesson = $module;
            break;
        }
    }
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['complete'])) {
        $now = date('Y-m-d H:i:s');
        $insert = $mysqli->prepare("INSERT INTO progress (user_id, lesson_id, completed, completed_at) VALUES (?, ?, 1, ?) ON DUPLICATE KEY UPDATE completed = 1, completed_at = ?");
        $insert->bind_param('iiss', $user['id'], $lesson_id, $now, $now);
        if ($insert->execute()) {
            $completed = 1;
            $message = 'Lesson marked complete.';
        } else {
            $message = 'Unable to update progress.';
        }
        $insert->close();
    }
}

include 'includes/header.php';
?>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="bg-white rounded-4 shadow-sm p-4 mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h1 class="h3 mb-1"><?= htmlspecialchars($lesson['title']) ?></h1>
                                <p class="text-muted mb-0">Course: <a href="course.php?id=<?= $lesson['course_id'] ?>"><?= htmlspecialchars($lesson['course_title']) ?></a></p>
                            </div>
                            <span class="badge bg-<?= $completed ? 'success' : 'secondary' ?>"><?= $completed ? 'Completed' : 'In Progress' ?></span>
                        </div>
                        <?php if ($message): ?>
                            <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
                        <?php endif; ?>
                        <p class="mb-3 text-muted"><?= htmlspecialchars($lesson['content']) ?></p>
                        <?php if (!empty($lesson['material_file'])): ?>
                            <div class="ratio ratio-16x9 mb-3">
                                <iframe src="<?= htmlspecialchars(MATERIALS_PATH . '/' . rawurlencode($lesson['material_file'])) ?>" frameborder="0" allowfullscreen></iframe>
                            </div>
                            <p><a href="<?= htmlspecialchars(MATERIALS_PATH . '/' . rawurlencode($lesson['material_file'])) ?>" target="_blank" class="btn btn-outline-primary">Open PDF in Full Screen</a></p>
                        <?php elseif (!empty($lesson['content'])): ?>
                            <div class="mb-3 text-muted"> <?= nl2br(htmlspecialchars($lesson['content'])) ?></div>
                        <?php else: ?>
                            <div class="alert alert-warning">No material or lesson content is available for this lesson yet.</div>
                        <?php endif; ?>
                        <form method="post">
                            <button type="submit" name="complete" class="btn btn-primary" <?= $completed ? 'disabled' : '' ?>><?= $completed ? 'Lesson Completed' : 'Mark as Completed' ?></button>
                            <a href="course.php?id=<?= $lesson['course_id'] ?>" class="btn btn-secondary ms-2">Back to Course</a>
                        </form>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="bg-white rounded-4 shadow-sm p-4 mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0">Course Modules</h5>
                            <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#moduleSidebar" aria-expanded="true" aria-controls="moduleSidebar">
                                Toggle
                            </button>
                        </div>
                        <div class="collapse show" id="moduleSidebar">
                            <div class="list-group course-module-list">
                                <?php foreach ($modules as $module): ?>
                                    <a href="lesson.php?id=<?= $module['id'] ?>" class="list-group-item list-group-item-action module-item<?= $module['id'] === $lesson_id ? ' active' : '' ?><?= $module['completed'] ? ' list-group-item-success' : '' ?>">
                                        <div class="d-flex w-100 justify-content-between align-items-center">
                                            <div>
                                                <strong><?= htmlspecialchars($module['title']) ?></strong>
                                                <div class="small text-muted"><?= $module['completed'] ? 'Completed' : ($module['id'] === $lesson_id ? 'Current lesson' : 'Not started') ?></div>
                                            </div>
                                            <span class="badge module-badge bg-<?= $module['completed'] ? 'success' : ($module['id'] === $lesson_id ? 'primary' : 'secondary') ?> rounded-pill"><?= $module['sort_order'] ?></span>
                                        </div>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <div class="bg-light rounded-4 shadow-sm p-4">
                        <h5>Lesson Info</h5>
                        <ul class="list-unstyled">
                            <li><strong>Material:</strong> <?= htmlspecialchars($lesson['material_file'] ?: 'No file attached') ?></li>
                            <li><strong>Uploaded:</strong> <?= htmlspecialchars($lesson['created_at']) ?></li>
                            <li><strong>Status:</strong> <?= $completed ? 'Completed' : 'Not yet completed' ?></li>
                        </ul>
                        <?php if ($nextLesson): ?>
                            <a href="lesson.php?id=<?= $nextLesson['id'] ?>" class="btn btn-outline-primary w-100">Next: <?= htmlspecialchars($nextLesson['title']) ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include 'includes/footer.php';
