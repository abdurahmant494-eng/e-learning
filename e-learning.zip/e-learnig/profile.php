<?php
require_once 'auth.php';
require_login();
$user = current_user();

// Handle avatar upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_avatar']) && !empty($_FILES['avatar']['name'])) {
    $file = $_FILES['avatar'];
    if ($file['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['png', 'jpg', 'jpeg', 'gif'];
        if (in_array($ext, $allowed) && $file['size'] <= 2 * 1024 * 1024) {
            $filename = 'avatar_' . $user['id'] . '_' . time() . '.' . $ext;
            $destDir = __DIR__ . '/' . AVATAR_PATH;
            if (!is_dir($destDir)) mkdir($destDir, 0755, true);
            $dest = $destDir . '/' . $filename;
            if (move_uploaded_file($file['tmp_name'], $dest)) {
                $stmt = $mysqli->prepare("UPDATE users SET avatar = ? WHERE id = ?");
                $stmt->bind_param('si', $filename, $user['id']);
                $stmt->execute();
                $stmt->close();
                $_SESSION['user']['avatar'] = $filename;
                $user['avatar'] = $filename;
            }
        }
    }
}

$completedLessons = 0;
$totalLessons = 0;
$courseProgress = [];
if ($mysqli) {
    $stmt = $mysqli->prepare("SELECT COUNT(*) AS completed FROM progress WHERE user_id = ? AND completed = 1");
    if ($stmt) {
        $stmt->bind_param('i', $user['id']);
        $stmt->execute();
        $stmt->bind_result($completedLessons);
        $stmt->fetch();
        $stmt->close();
    }

    $stmt = $mysqli->prepare("SELECT COUNT(*) AS total FROM lessons");
    if ($stmt) {
        $stmt->execute();
        $stmt->bind_result($totalLessons);
        $stmt->fetch();
        $stmt->close();
    }

    $stmt = $mysqli->prepare(
        "SELECT c.id, c.title, COUNT(l.id) AS total_lessons, IFNULL(SUM(p.completed), 0) AS completed_lessons
         FROM courses c
         JOIN lessons l ON l.course_id = c.id
         LEFT JOIN progress p ON p.lesson_id = l.id AND p.user_id = ?
         GROUP BY c.id
         ORDER BY c.id DESC"
    );
    if ($stmt) {
        $stmt->bind_param('i', $user['id']);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $courseProgress[] = $row;
        }
        $stmt->close();
    }
}

$title = 'Profile';
include 'includes/header.php';
?>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="p-5 bg-white rounded-4 shadow-sm">
                        <div class="d-flex align-items-center justify-content-between mb-4">
                            <div>
                                <h1 class="mb-2">My Profile</h1>
                                <p class="text-muted mb-0">Manage your account details and access courses.</p>
                            </div>
                            <a href="logout.php" class="btn btn-secondary">Logout</a>
                        </div>
                        <div class="row g-4">
                            <div class="col-md-4 text-center">
                                <div class="p-4 border rounded-4 bg-light">
                                    <h5 class="mb-3">Avatar</h5>
                                    <img src="<?= htmlspecialchars((isset($user['avatar']) ? AVATAR_PATH . '/' . $user['avatar'] : IMG_PATH . '/team-1.jpg')) ?>" class="img-fluid rounded-circle mb-3" style="width:120px; height:120px; object-fit:cover;" alt="avatar">
                                    <form method="post" action="profile.php" enctype="multipart/form-data">
                                        <input type="file" name="avatar" accept="image/*" class="form-control mb-2">
                                        <button class="btn btn-primary btn-sm" type="submit" name="upload_avatar">Upload</button>
                                    </form>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="p-4 border rounded-4 bg-light">
                                    <h5 class="mb-3">Account</h5>
                                    <p class="mb-0"><strong>Name:</strong> <?= htmlspecialchars($user['name']) ?></p>
                                    <p class="mb-0"><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="row g-4 mt-4">
                            <div class="col-md-6">
                                <div class="p-4 border rounded-4 bg-white h-100">
                                    <h5 class="mb-3">Learning Progress</h5>
                                    <p class="mb-2"><strong><?= $completedLessons ?></strong> lessons completed</p>
                                    <p class="mb-0"><strong><?= $totalLessons ?></strong> lessons available</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="p-4 border rounded-4 bg-white h-100">
                                    <h5 class="mb-3">Course Progress</h5>
                                    <?php if (empty($courseProgress)): ?>
                                        <p class="mb-0">No active courses yet. Start a course to track progress.</p>
                                    <?php else: ?>
                                        <?php foreach ($courseProgress as $course): ?>
                                            <?php $percent = $course['total_lessons'] > 0 ? intval(($course['completed_lessons'] / $course['total_lessons']) * 100) : 0; ?>
                                            <div class="mb-3">
                                                <div class="d-flex justify-content-between">
                                                    <span><?= htmlspecialchars($course['title']) ?></span>
                                                    <strong><?= $percent ?>%</strong>
                                                </div>
                                                <div class="progress" style="height: 12px;">
                                                    <div class="progress-bar" role="progressbar" style="width: <?= $percent ?>%;" aria-valuenow="<?= $percent ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="mt-4 p-4 border rounded-4 bg-white">
                            <h5 class="mb-3">Welcome back, <?= htmlspecialchars($user['name']) ?>!</h5>
                            <p class="mb-0">Use the navigation to explore courses, contact support, or update your profile details.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include 'includes/footer.php';
