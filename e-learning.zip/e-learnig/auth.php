<?php
require_once __DIR__ . '/db.php';

function is_logged_in(): bool {
    return !empty($_SESSION['user']);
}

function current_user(): ?array {
    return $_SESSION['user'] ?? null;
}

function require_login(): void {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function redirect_if_logged_in(): void {
    if (is_logged_in()) {
        redirect_to_dashboard();
    }
}

function is_admin(): bool {
    $user = current_user();
    return $user && ($user['is_admin'] === 1 || $user['role'] === 'admin');
}

function is_instructor(): bool {
    $user = current_user();
    return $user && $user['role'] === 'instructor';
}

function is_student(): bool {
    $user = current_user();
    return $user && $user['role'] === 'student';
}

function require_admin(): void {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
    if (!is_admin()) {
        header('HTTP/1.0 403 Forbidden');
        echo '<h1>403 - Access Denied</h1><p>You do not have permission to access this page.</p>';
        exit;
    }
}

function require_instructor(): void {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
    if (!is_instructor()) {
        header('HTTP/1.0 403 Forbidden');
        echo '<h1>403 - Access Denied</h1><p>Only instructors can access this page.</p>';
        exit;
    }
}

function require_student(): void {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
    if (!is_student()) {
        header('HTTP/1.0 403 Forbidden');
        echo '<h1>403 - Access Denied</h1><p>Only students can access this page.</p>';
        exit;
    }
}

function redirect_to_dashboard(): void {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }

    if (is_admin()) {
        header('Location: admin/index.php');
        exit;
    }

    if (is_instructor()) {
        header('Location: instructor/index.php');
        exit;
    }

    header('Location: student/index.php');
    exit;
}

function require_role(string $role): void {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
    $user = current_user();
    if ($user['role'] !== $role) {
        header('HTTP/1.0 403 Forbidden');
        echo '<h1>403 - Access Denied</h1><p>You do not have permission to access this page.</p>';
        exit;
    }
}
