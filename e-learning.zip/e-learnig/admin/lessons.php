<?php
require_once __DIR__ . '/../auth.php';
require_admin();
require_once __DIR__ . '/../db.php';

$q = "SELECT l.*, c.title AS course_title FROM lessons l LEFT JOIN courses c ON l.course_id = c.id ORDER BY l.created_at DESC";
$res = $mysqli->query($q);
$lessons = [];
if ($res) {
    while ($row = $res->fetch_assoc()) $lessons[] = $row;
}

$titlePage = 'Manage Lessons';
include __DIR__ . '/../includes/header.php';
?>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 class="mb-4">Manage Lessons</h1>
                    <a href="upload_material.php" class="btn btn-success mb-3">Create New Lesson</a>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Course</th>
                                    <th>Material</th>
                                    <th>Video</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($lessons as $l): ?>
                                    <tr>
                                        <td><?= $l['id'] ?></td>
                                        <td><?= htmlspecialchars($l['title']) ?></td>
                                        <td><?= htmlspecialchars($l['course_title'] ?? '—') ?></td>
                                        <td><?php if (!empty($l['material_file'])): ?>
                                            <a href="<?= '../' . MATERIALS_PATH . '/' . $l['material_file'] ?>" target="_blank">Download</a>
                                        <?php else: ?>—<?php endif; ?></td>
                                        <td><?= $l['video_url'] ? '<a href="' . htmlspecialchars($l['video_url']) . '" target="_blank">View</a>' : '—' ?></td>
                                        <td><?= $l['created_at'] ?></td>
                                        <td>
                                            <a href="edit_lesson.php?id=<?= $l['id'] ?>" class="btn btn-sm btn-primary">Edit</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include __DIR__ . '/../includes/footer.php';
