<?php
require_once __DIR__ . '/../auth.php';
require_login();
$user = current_user();
if (!is_admin() && !is_instructor()) {
    header('HTTP/1.0 403 Forbidden');
    echo '<h1>403 - Access Denied</h1><p>Only instructors or admins can upload course materials.</p>';
    exit;
}

// db connection available via auth include
require_once __DIR__ . '/../db.php';

$message = '';
// Fetch courses for selection
$courses = [];
$res = $mysqli->query("SELECT id, title FROM courses ORDER BY title ASC");
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $courses[] = $row;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_id = intval($_POST['course_id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $video_url = trim($_POST['video_url'] ?? '');

    // Validate course
    if ($course_id <= 0) {
        $message = 'Please select a course.';
    } elseif (empty($title)) {
        $message = 'Please provide a lesson title.';
    } else {
        // Handle file upload if provided
        $uploadedFilename = null;
        if (!empty($_FILES['material']['name']) && $_FILES['material']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['material'];
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $allowed = ['pdf','doc','docx','ppt','pptx','zip','mp4','mov','png','jpg','jpeg'];
            if (!in_array($ext, $allowed)) {
                $message = 'File type not allowed.';
            } elseif ($file['size'] > 50 * 1024 * 1024) {
                $message = 'File too large (max 50MB).';
            } else {
                $filename = 'material_' . $course_id . '_' . time() . '.' . $ext;
                $destDir = __DIR__ . '/../' . MATERIALS_PATH;
                if (!is_dir($destDir)) mkdir($destDir, 0755, true);
                $dest = $destDir . '/' . $filename;
                if (move_uploaded_file($file['tmp_name'], $dest)) {
                    $uploadedFilename = $filename;
                } else {
                    $message = 'Failed to move uploaded file.';
                }
            }
        }

        if (empty($message)) {
            // Insert lesson
            $stmt = $mysqli->prepare("INSERT INTO lessons (course_id, title, content, video_url, material_file) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param('issss', $course_id, $title, $content, $video_url, $uploadedFilename);
            if ($stmt->execute()) {
                $message = 'Lesson created successfully.';
            } else {
                $message = 'Database error: ' . $mysqli->error;
            }
            $stmt->close();
        }
    }
}

$titlePage = 'Upload Material';
include __DIR__ . '/../includes/header.php';
?>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h1 class="mb-4">Upload Course Material / Create Lesson</h1>
                    <?php if ($message): ?>
                        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
                    <?php endif; ?>
                    <form method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">Course</label>
                            <select name="course_id" class="form-select">
                                <option value="">-- Select course --</option>
                                <?php foreach ($courses as $c): ?>
                                    <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['title']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Lesson Title</label>
                            <input type="text" name="title" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Content / Description</label>
                            <textarea name="content" class="form-control" rows="4"></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Video URL (YouTube/Vimeo)</label>
                            <input type="text" name="video_url" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Material File (optional)</label>
                            <input type="file" name="material" class="form-control">
                        </div>
                        <button class="btn btn-primary">Create Lesson</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php include __DIR__ . '/../includes/footer.php';
