<?php
require_once __DIR__ . '/../auth.php';
require_admin();

$title = 'Admin Dashboard';
$page = 'admin';
include __DIR__ . '/../includes/header.php';
?>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 class="mb-4">Admin Dashboard</h1>
                    <p class="mb-4">Use the admin tools below to manage the platform content, courses, lessons, and users.</p>
                    <div class="list-group">
                        <a href="upload_material.php" class="list-group-item list-group-item-action">Upload Course Material / Create Lesson</a>
                        <a href="lessons.php" class="list-group-item list-group-item-action">Manage Lessons</a>
                        <a href="manage_courses.php" class="list-group-item list-group-item-action">Manage Courses</a>
                        <a href="manage_users.php" class="list-group-item list-group-item-action">Manage Users</a>
                        <a href="invite_user.php" class="list-group-item list-group-item-action">Invite / Create User</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include __DIR__ . '/../includes/footer.php';
