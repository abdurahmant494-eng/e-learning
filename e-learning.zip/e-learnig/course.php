<?php
$page = 'courses';
$title = 'Course Details';
require_once 'auth.php';
require_login();
$user = current_user();

$course_id = intval($_GET['id'] ?? 0);
if ($course_id <= 0) {
    header('Location: courses.php');
    exit;
}

$stmt = $mysqli->prepare("SELECT * FROM courses WHERE id = ? LIMIT 1");
$stmt->bind_param('i', $course_id);
$stmt->execute();
$course = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$course) {
    header('Location: courses.php');
    exit;
}

$lessonStmt = $mysqli->prepare(
    "SELECT l.*, IFNULL(p.completed, 0) AS completed
     FROM lessons l
     LEFT JOIN progress p ON p.lesson_id = l.id AND p.user_id = ?
     WHERE l.course_id = ?
     ORDER BY l.sort_order ASC, l.id ASC"
);
$lessonStmt->bind_param('ii', $user['id'], $course_id);
$lessonStmt->execute();
$lessons = $lessonStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$lessonStmt->close();

$totalLessons = count($lessons);
$completedLessons = 0;
$nextLesson = null;
foreach ($lessons as $lesson) {
    if ($lesson['completed']) {
        $completedLessons++;
    } elseif ($nextLesson === null) {
        $nextLesson = $lesson;
    }
}
if ($nextLesson === null && !empty($lessons)) {
    $nextLesson = end($lessons);
}
$progressPercent = $totalLessons > 0 ? intval(($completedLessons / $totalLessons) * 100) : 0;

include 'includes/header.php';
?>

    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-4 mb-5">
                <div class="col-lg-8">
                    <div class="bg-white rounded-4 shadow-sm p-4">
                        <h1 class="mb-3"><?= htmlspecialchars($course['title']) ?></h1>
                        <p class="text-muted mb-3"><?= htmlspecialchars($course['description']) ?></p>
                        <div class="mb-4">
                            <span class="badge bg-primary me-2">Teacher: <?= htmlspecialchars($course['teacher']) ?></span>
                            <span class="badge bg-secondary me-2">Duration: <?= htmlspecialchars($course['duration']) ?></span>
                            <span class="badge bg-info">Lessons: <?= $totalLessons ?></span>
                        </div>
                        <h5 class="mb-2">Your Progress</h5>
                        <div class="progress mb-3" style="height: 24px;">
                            <div class="progress-bar bg-success" role="progressbar" style="width: <?= $progressPercent ?>%;" aria-valuenow="<?= $progressPercent ?>" aria-valuemin="0" aria-valuemax="100"><?= $progressPercent ?>%</div>
                        </div>
                        <?php if ($progressPercent === 100 && $totalLessons > 0): ?>
                            <div class="alert alert-success">Congratulations! You have completed all lessons for this course.</div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="h-100 bg-light rounded-4 p-4">
                        <h5>Course Overview</h5>
                        <p>Complete each lesson in order and mark it done to track your achievement. Your course progress updates automatically as you finish lessons.</p>
                        <div class="d-flex justify-content-between">
                            <div><strong>Completed</strong></div>
                            <div><?= $completedLessons ?> / <?= $totalLessons ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="bg-white rounded-4 shadow-sm p-4 mb-4">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <div>
                                <h3 class="mb-2">Course Outline</h3>
                                <p class="text-muted mb-0">Learn at your own pace with a guided lesson path.</p>
                            </div>
                            <div class="d-flex gap-2 align-items-center">
                                <span class="badge bg-info">Progress <?= $progressPercent ?>%</span>
                                <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#courseOutlineCollapse" aria-expanded="true" aria-controls="courseOutlineCollapse">Toggle Outline</button>
                            </div>
                        </div>
                        <p class="mb-3"><?= $completedLessons ?> of <?= $totalLessons ?> lessons completed.</p>
                        <?php if ($nextLesson): ?>
                            <div class="alert alert-primary">
                                Next lesson: <strong><?= htmlspecialchars($nextLesson['title']) ?></strong>
                            </div>
                            <a href="lesson.php?id=<?= $nextLesson['id'] ?>" class="btn btn-primary mb-3"><?= $completedLessons ? 'Continue Next Lesson' : 'Start Course' ?></a>
                        <?php endif; ?>
                        <div class="collapse show" id="courseOutlineCollapse">
                            <div class="bg-light rounded-4 p-4">
                            <h5 class="mb-3">Tips</h5>
                            <ul class="mb-0">
                                <li>Complete each lesson to track your progress.</li>
                                <li>Use the sidebar to jump to unlocked lessons.</li>
                                <li>PDF materials open in full-screen mode for focused reading.</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="bg-white rounded-4 shadow-sm p-4 h-100">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0">Lesson Modules</h5>
                            <button class="btn btn-sm btn-outline-secondary course-collapse-toggle" type="button" data-bs-toggle="collapse" data-bs-target="#courseModulesSidebar" aria-expanded="true" aria-controls="courseModulesSidebar">
                                <span class="collapse-toggle-icon">▾</span>
                                <span class="ms-1">Toggle</span>
                            </button>
                        </div>
                        <div class="collapse show" id="courseModulesSidebar">
                            <?php if (empty($lessons)): ?>
                                <p class="text-muted">No lessons are available yet.</p>
                            <?php else: ?>
                                <div class="list-group course-module-list">
                                    <?php foreach ($lessons as $lesson): ?>
                                        <a href="lesson.php?id=<?= $lesson['id'] ?>" class="list-group-item list-group-item-action module-item<?= $lesson['completed'] ? ' list-group-item-success' : '' ?><?= ($nextLesson && $lesson['id'] === $nextLesson['id']) ? ' active' : '' ?>">
                                            <div class="d-flex w-100 justify-content-between align-items-center">
                                                <div>
                                                    <h6 class="mb-1"><?= htmlspecialchars($lesson['title']) ?></h6>
                                                    <small class="text-muted"><?= htmlspecialchars($lesson['content']) ?></small>
                                                </div>
                                                <span class="badge module-badge bg-<?= $lesson['completed'] ? 'success' : ($nextLesson && $lesson['id'] === $nextLesson['id'] ? 'primary' : 'secondary') ?> rounded-pill"><?= $lesson['completed'] ? 'Done' : ($nextLesson && $lesson['id'] === $nextLesson['id'] ? 'Next' : 'Pending') ?></span>
                                            </div>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                                <?php if ($nextLesson): ?>
                                    <div class="mt-4 p-3 bg-light rounded-4 border">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <div><strong>Next lesson progress</strong></div>
                                            <div class="small text-muted"><?= min($completedLessons + 1, $totalLessons) ?> / <?= $totalLessons ?></div>
                                        </div>
                                        <div class="progress" style="height: 10px;">
                                            <div class="progress-bar bg-primary" role="progressbar" style="width: <?= $progressPercent ?>%;" aria-valuenow="<?= $progressPercent ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <div class="small text-muted mt-2">Continue with <strong><?= htmlspecialchars($nextLesson['title']) ?></strong></div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include 'includes/footer.php';
