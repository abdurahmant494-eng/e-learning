<?php
require_once 'db.php';
if (!empty($_SESSION['user'])) {
    unset($_SESSION['user']);
}
session_destroy();
header('Location: index.php');
exit;
