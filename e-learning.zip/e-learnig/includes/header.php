<?php
if (!defined('CSS_PATH')) {
    require_once __DIR__ . '/../config.php';
}
function nav_active($slug) {
    global $page;
    return isset($page) && $page === $slug ? 'active' : '';
}
function pages_dropdown_active() {
    global $page;
    return in_array($page, ['team', 'testimonial', '404']) ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?= htmlspecialchars($title ?? 'eLEARNING') ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="eLearning HTML Template" name="description">
    <meta content="online learning, courses, education" name="keywords">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?= BASE_URL ?>/<?= LIB_PATH ?>/animate/animate.min.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>/<?= LIB_PATH ?>/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?= BASE_URL ?>/<?= CSS_PATH ?>/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?= BASE_URL ?>/<?= CSS_PATH ?>/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="<?= BASE_URL ?>/index.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <img src="<?= BASE_URL ?>/<?= IMG_PATH ?>/logo.jpg" alt="Borana University Logo" class="me-3" style="height:45px; width:auto;">
            <div>
                <h4 class="m-0 text-primary">Borana University</h4>
                <small class="text-muted">E-Learning Platform</small>
            </div>
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <a href="<?= BASE_URL ?>/index.php" class="nav-item nav-link <?= nav_active('home') ?>">Home</a>
                <a href="<?= BASE_URL ?>/about.php" class="nav-item nav-link <?= nav_active('about') ?>">About</a>
                <a href="<?= BASE_URL ?>/courses.php" class="nav-item nav-link <?= nav_active('courses') ?>">Courses</a>
                <?php if (!empty($_SESSION['user'])): ?>
                    <?php if ($_SESSION['user']['role'] === 'admin'): ?>
                        <a href="<?= BASE_URL ?>/dashboard.php" class="nav-item nav-link <?= nav_active('admin') ?>">Admin Dashboard</a>
                    <?php elseif ($_SESSION['user']['role'] === 'instructor'): ?>
                        <a href="<?= BASE_URL ?>/dashboard.php" class="nav-item nav-link <?= nav_active('instructor') ?>">Instructor Dashboard</a>
                    <?php elseif ($_SESSION['user']['role'] === 'student'): ?>
                        <a href="<?= BASE_URL ?>/dashboard.php" class="nav-item nav-link <?= nav_active('student') ?>">Student Dashboard</a>
                    <?php endif; ?>
                <?php endif; ?>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle <?= pages_dropdown_active() ?>" data-bs-toggle="dropdown">Pages</a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="<?= BASE_URL ?>/team.php" class="dropdown-item <?= nav_active('team') ?>">Our Team</a>
                        <a href="<?= BASE_URL ?>/testimonial.php" class="dropdown-item <?= nav_active('testimonial') ?>">Testimonial</a>
                        <a href="<?= BASE_URL ?>/404.php" class="dropdown-item <?= nav_active('404') ?>">404 Page</a>
                    </div>
                </div>
                <a href="<?= BASE_URL ?>/contact.php" class="nav-item nav-link <?= nav_active('contact') ?>">Contact</a>
                <?php if (!empty($_SESSION['user'])): ?>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-user-circle me-1"></i><?= htmlspecialchars($_SESSION['user']['name']) ?>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end fade-down m-0">
                            <a href="<?= BASE_URL ?>/profile.php" class="dropdown-item">My Profile</a>
                            <a href="<?= BASE_URL ?>/logout.php" class="dropdown-item">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="<?= BASE_URL ?>/login.php" class="nav-item nav-link d-lg-none">Login</a>
                    <a href="<?= BASE_URL ?>/signup.php" class="nav-item nav-link d-lg-none">Sign Up</a>
                <?php endif; ?>
            </div>
            <?php if (!empty($_SESSION['user'])): ?>
                <div class="d-none d-lg-flex align-items-center">
                    <a href="<?= BASE_URL ?>/profile.php" class="btn btn-secondary py-3 px-lg-4 me-2">Profile</a>
                    <a href="<?= BASE_URL ?>/logout.php" class="btn btn-primary py-3 px-lg-4">Logout</a>
                </div>
            <?php else: ?>
                <div class="d-none d-lg-flex align-items-center">
                    <a href="<?= BASE_URL ?>/login.php" class="btn btn-secondary py-3 px-lg-4 me-2">Login</a>
                    <a href="<?= BASE_URL ?>/signup.php" class="btn btn-primary py-3 px-lg-4">Sign Up</a>
                </div>
            <?php endif; ?>
        </div>
    </nav>
    <!-- Navbar End -->
