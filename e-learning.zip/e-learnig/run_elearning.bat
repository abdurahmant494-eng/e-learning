@echo off
REM Run this script from the project root in XAMPP htdocs.
SETLOCAL ENABLEDELAYEDEXPANSION
cd /d "%~dp0"

REM Detect XAMPP root by moving two levels up from htdocs\e-learnig
SET "XAMPP_ROOT=%~dp0..\.."
IF EXIST "%XAMPP_ROOT%\apache_start.bat" (
    echo Starting Apache...
    start "" "%XAMPP_ROOT%\apache_start.bat"
) ELSE (
    echo WARNING: Apache start script not found at %XAMPP_ROOT%\apache_start.bat
)

IF EXIST "%XAMPP_ROOT%\mysql_start.bat" (
    echo Starting MySQL...
    start "" "%XAMPP_ROOT%\mysql_start.bat"
) ELSE (
    echo WARNING: MySQL start script not found at %XAMPP_ROOT%\mysql_start.bat
)

echo Opening browser to http://localhost/e-learnig/index.php
start "" "http://localhost/e-learnig/index.php"
ENDLOCAL
